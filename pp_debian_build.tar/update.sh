#!/bin/bash
cd ProjectPrinter
git pull
dotnet build /p:EnableWindowsTargeting=true
cp -rv ProjectPrinter/bin/Debug/net9.0/* build
cp -rv device_config/bin/Debug/net9.0/* build
cd ProjectPrinter/build

