#!/bin/bash
wget https://packages.microsoft.com/config/debian/12/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
sudo dpkg -i packages-microsoft-prod.deb
rm packages-microsoft-prod.deb
sudo apt-get update && \
  sudo apt-get install -y dotnet-sdk-9.0
sudo apt-get install -y dotnet-runtime-9.0
sudo apt-get install -y git
sudo apt-get update
sudo apt-get upgrade
git clone https://github.com/SComps/ProjectPrinter.git
cd ProjectPrinter
mkdir build
sudo dotnet workload update
dotnet build /p:EnableWindowsTargeting=true
cp -rv ProjectPrinter/bin/Debug/net9.0/* build
cp -rv device_config/bin/Debug/net9.0/* build
cd ProjectPrinter/build

