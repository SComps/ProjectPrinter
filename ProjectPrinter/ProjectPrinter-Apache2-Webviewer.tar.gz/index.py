#!/usr/bin/env python3
"""
PrinterView CGI Script
Lists PDF files in the /printer directory and its subdirectories (users).
"""

import os
import sys
import datetime
import html
import glob

# Configuration
# Subdirectories directly under this path are considered 'users'
# This path should be absolute or relative to the script location
# For testing locally, use './printer_root', for production use '/printer'
PRINTER_ROOT = os.environ.get('PRINTER_ROOT', '/printer')
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def get_file_info(filepath):
    """Returns a dictionary with file info."""
    try:
        stat = os.stat(filepath)
        size_mb = stat.st_size / (1024 * 1024)
        mtime = datetime.datetime.fromtimestamp(stat.st_mtime)
        return {
            'name': os.path.basename(filepath),
            'path': filepath,
            'rel_path': os.path.relpath(filepath, PRINTER_ROOT),
            'size': f"{size_mb:.2f} MB",
            'date': mtime.strftime("%Y-%m-%d %H:%M"),
            'timestamp': stat.st_mtime
        }
    except Exception as e:
        return None

def get_pdf_files(directory):
    """Returns a list of PDF files in the given directory."""
    files = []
    if not os.path.exists(directory):
        return []
        
    for filename in os.listdir(directory):
        if filename.lower().endswith('.pdf'):
            filepath = os.path.join(directory, filename)
            if os.path.isfile(filepath):
                info = get_file_info(filepath)
                if info:
                    files.append(info)
    
    # Sort by date descending (newest first)
    files.sort(key=lambda x: x['timestamp'], reverse=True)
    return files

def get_users_and_files():
    """Scans for user directories and their PDF files."""
    users = {}
    if not os.path.exists(PRINTER_ROOT):
        return users

    # Get all potential user directories
    try:
        entries = os.listdir(PRINTER_ROOT)
        for entry in entries:
            full_path = os.path.join(PRINTER_ROOT, entry)
            if os.path.isdir(full_path):
                # Security Check: Verify if the directory is actually public by checking .htaccess for "Require all granted"
                is_actually_protected = True
                htaccess_path = os.path.join(full_path, '.htaccess')
                if os.path.exists(htaccess_path):
                    try:
                        with open(htaccess_path, 'r') as f:
                            content = f.read().lower()
                            if 'require all granted' in content:
                                is_actually_protected = False
                    except Exception as e:
                        sys.stderr.write(f"Error reading .htaccess in {entry}: {e}\n")
                
                # Get PDFs
                user_files = get_pdf_files(full_path)
                if user_files:
                    users[entry] = {
                        'files': user_files,
                        'protected': is_actually_protected
                    }
    except Exception as e:
        sys.stderr.write(f"Error scanning directories: {e}\n")
        
    return users

def render_file_card(file_data, is_protected=False):
    """Generates HTML for a single file card."""
    web_path = f"/printer/{file_data['rel_path']}" 
    web_path = html.escape(web_path.replace("\\", "/"))

    icon_svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="currentColor" class="file-icon">
  <path d="M25.7,9.3l-7-7C18.5,2.1,18.3,2,18,2H8C6.9,2,6,2.9,6,4v24c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V10C26,9.7,25.9,9.5,25.7,9.3z M18,4.4l5.6,5.6H18V4.4z M24,28H8V4h8v8h8V28z"/>
</svg>"""

    lock_badge = ""
    target_attr = ""
    
    if is_protected:
        lock_badge = '<div class="badge-locked">Restricted</div>'
        target_attr = 'target="_blank"'

    return f"""
    <a href="{web_path}" class="file-card" {target_attr}>
        {icon_svg}
        <div class="file-content">
            <div class="file-name" title="{html.escape(file_data['name'])}">{html.escape(file_data['name'])}</div>
            <div class="file-meta">{file_data['size']} • {file_data['date']}</div>
            {lock_badge}
        </div>
    </a>
    """

def main():
    # Print HTTP Header
    print("Content-Type: text/html; charset=utf-8\n")
    
    # Check for CSS file
    css_content = ""
    css_path = os.path.join(SCRIPT_DIR, 'style.css')
    if os.path.exists(css_path):
        with open(css_path, 'r') as f:
            css_content = f.read()
    
    # Get Data
    shared_files = get_pdf_files(PRINTER_ROOT)
    user_data = get_users_and_files()
    
    # Start HTML
    print(f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IBM Z | ZOSP I z/OS 3.1 | Printer Spool View</title>
    <style>
        {css_content}
    </style>
</head>
<body>
    <header>
        <h1><span>IBM Z | ZOSP I z/OS 3.1</span> Printer Spool View</h1>
    </header>
    
    <main class="container">
    """)
    
    # Shared Section
    print('<div class="section">')
    print('<h2 class="section-title"><svg viewBox="0 0 32 32" fill="currentColor"><path d="M16 4L6 14l1.41 1.41L15 7.83V28h2V7.83l7.59 7.58L26 14L16 4z"/></svg> Global Spool (Public)</h2>')
    
    if shared_files:
        print('<div class="file-list">')
        for f in shared_files:
            print(render_file_card(f, is_protected=False))
        print('</div>')
    else:
        print('<div class="empty-state">No datasets found in the global spool.</div>')
    print('</div>') # End Section

    # Users Section
    if user_data:
        print('<div class="section">')
        print('<h2 class="section-title"><svg viewBox="0 0 32 32" fill="currentColor"><path d="M26,30H14a2,2,0,0,1-2-2V2H26a2,2,0,0,1,2,2V28A2,2,0,0,1,26,30ZM14,4V28H26V4Z"/><path d="M6,6H4V28a2,2,0,0,0,2,2H22V28H6Z"/></svg> Workspaces (Individual Spools)</h2>')
        
        # Get Current Authenticated User for comparison
        current_viewer = os.environ.get('REMOTE_USER', '').upper()

        # Sort users alphabetically
        for user in sorted(user_data.keys()):
            user_info = user_data[user]
            files = user_info['files']
            is_protected = user_info['protected']
            upper_user = user.upper()
            encoded_user = html.escape(user)
            
            is_owner = (current_viewer == upper_user)
            
            if is_protected:
                if is_owner:
                    protection_badge = '<span class="badge-locked">Authorized (Owner)</span>'
                else:
                    protection_badge = '<span class="badge-locked">Restricted (System)</span>'
            else:
                protection_badge = '<span class="badge-unprotected">Public View</span>'
            
            print(f'<div class="user-group">')
            print(f'<div class="user-header"><span>{encoded_user.upper()}</span> {protection_badge}</div>')
            print('<div class="file-list">')
            for f in files:
                # If protected but not owner, we still show the files but 
                # they will prompt for a different password when clicked.
                print(render_file_card(f, is_protected=is_protected))
            print('</div></div>')

            
        print('</div>')
    
    print("""
    </main>
</body>
</html>
    """)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # In case of catastrophic error, print basic trace to stdout so it shows in browser (development mode)
        # For production you might want to log this instead.
        print("Content-Type: text/plain\n")
        print("An error occurred executing the script:")
        print(e)
        import traceback
        traceback.print_exc()
