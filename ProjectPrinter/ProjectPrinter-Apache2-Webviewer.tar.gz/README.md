## Overview

PrinterView is a secure, visually professional dashboard for managing and viewing mainframe printouts (PDFs). Designed with the **IBM Carbon Design System**, it creates a modern z/OS-inspired experience for browsing spool files.

For full technical details, see the:
- [USER_MANUAL.txt](USER_MANUAL.txt)

## Key Features
- **Privacy by Default**: Automatic User Isolation ensures users can only see their own work.
- **Z/OS Aesthetics**: High-fidelity IBM Carbon styling (Gray 10 Dark mode).
- **Public Overrides**: Easily mark system folders (like SYSLOG) as public for shared viewing.
- **Automated Deployment**: One-click scripts for installation and configuration.

## Installation & Setup

### 1. Automated Installation (Debian/Ubuntu/DietPi)
For a fresh server, the automated script handles everything (dependencies, dirs, and Apache):
```bash
sudo ./setup_deb.sh [optional_spool_path]
```

### 2. Definitive Configuration (Maintenance)
To apply the latest isolation policy or fix a broken Apache config:
```bash
sudo ./regenerate_apache_config.sh /etc/apache2/sites-available/printer_view.conf [spool_path]
```

### 3. Live UI Updates
If you've modified `index.py` or `style.css` and want to push them to the server:
```bash
sudo ./update_live_site.sh
```

## Security & Privacy
PrinterView uses **Automatic User Isolation**:
- **Public Root**: Files in the spool root (default `/printer/`) are public.
- **Private Workspaces**: Any subfolder is automatically locked. A visitor can only open folder `/SCOTT/` if they authenticate as user `scott`.
- **Cross-Access Prevention**: Being logged in for one folder does NOT authorize you for others.

## Management Scripts
- `add_user.sh <username>`: Set up a workspace and create login credentials.
- `mark_public.sh <folder>`: Make a private workspace public for system/shared use.
- `mark_private.sh <folder>`: Re-lock a public folder using the global isolation policy.
- `protect_orphans.sh`: Interactively secure any unprotected subdirectories.

---
© 2026 PrinterView | IBM Carbon Design System v11
