#!/bin/bash
# regenerate_apache_config.sh
# Usage: sudo ./regenerate_apache_config.sh [optional_target_file] [optional_spool_dir]
# Completely replaces your Apache config with a fresh, isolated, and secure version.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

# Configuration: Default paths
TARGET_FILE="${1:-/etc/apache2/sites-available/printer_view.conf}"
SPOOL_DIR="${2:-/printer}"
WEB_APP_DIR="/var/www/printer_view"

echo "Regenerating Apache Configuration at: $TARGET_FILE"
echo "Targeting Spool Directory: $SPOOL_DIR"
echo "Cleaning out any old isolation policies..."

# Generate the complete fresh config
cat > "$TARGET_FILE" <<EOF
<VirtualHost *:80>
    # Printer Spool Management Interface
    DocumentRoot $WEB_APP_DIR

    # 1. Dashboard Interface Configuration
    <Directory $WEB_APP_DIR>
        Options +ExecCGI
        AddHandler cgi-script .py
        DirectoryIndex index.py
        AllowOverride All
        Require all granted
        
        # Tell the script where the real files are
        SetEnv PRINTER_ROOT $SPOOL_DIR
    </Directory>

    # 2. Main Spool Storage (Public Access for root datasets)
    Alias /printer $SPOOL_DIR
    <Directory $SPOOL_DIR>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # 3. WORKSPACE ISOLATION POLICY (Privacy by Default)
    # capture the workspace name into the 'OWNER' environment variable
    RewriteEngine On
    RewriteRule "^/printer/([^/]+)/" - [E=OWNER:$1]

    # Apply isolation to all subdirectories
    # Standard <Directory> blocks are processed BEFORE .htaccess, 
    # ensuring mark_public.sh can successfully override this policy.
    <Directory "$SPOOL_DIR/*">
        AuthType Basic
        AuthName "Printer Workspace Isolation"
        AuthUserFile /etc/apache2/.htpasswd
        
        # Isolation Logic:
        # 1. Deny access if they aren't the owner
        # 2. But let the local .htaccess override this if 'AllowOverride All' is set.
        <RequireAll>
            Require valid-user
            Require expr "%{REMOTE_USER} == %{env:OWNER}"
        </RequireAll>
        
        AllowOverride All
    </Directory>
</VirtualHost>
EOF

echo "Enabling Site and Reloading Apache..."
a2ensite $(basename $TARGET_FILE) || true
systemctl reload apache2

echo "============================================"
echo "[SUCCESS] Apache configuration has been REGENERATED."
echo "Location: $TARGET_FILE"
echo "Security: User Isolation is now ACTIVE."
echo "============================================"
