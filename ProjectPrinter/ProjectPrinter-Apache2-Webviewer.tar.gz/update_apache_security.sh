#!/bin/bash
# update_apache_security.sh
# Usage: sudo ./update_apache_security.sh [config_file]
# Automatically secures subdirectories in the Apache configuration.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

# Detect config file
CONFIG_FILES=("/etc/apache2/sites-available/printer.conf" "/etc/apache2/sites-available/printer_view.conf" "/etc/apache2/sites-available/000-default.conf")
TARGET_FILE=""
SPOOL_DIR="${2:-/printer}"

if [ -n "$1" ]; then
    TARGET_FILE="$1"
else
    # Auto-detect
    for f in "${CONFIG_FILES[@]}"; do
        if [ -f "$f" ] && grep -q "$SPOOL_DIR" "$f"; then
            TARGET_FILE="$f"
            break
        fi
    done
fi

if [ -z "$TARGET_FILE" ] || [ ! -f "$TARGET_FILE" ]; then
    echo "Error: Could not find an Apache configuration file targeting '$SPOOL_DIR'."
    echo "Please specify the file manually: sudo ./update_apache_security.sh /path/to/your/config.conf [spool_dir]"
    exit 1
fi

echo "Updating security policy in $TARGET_FILE for spool $SPOOL_DIR..."

# Check if DirectoryMatch already exists to avoid duplicates
if grep -q "Printer Workspace Isolation" "$TARGET_FILE"; then
    echo "Privacy policy already exists in $TARGET_FILE. No changes needed."
else
    # We use a temporary file for the block to avoid escaping issues with sed
    TEMP_BLOCK="/tmp/printer_block.txt"
    cat > "$TEMP_BLOCK" <<EOF
    # PRIVACY BY DEFAULT: RESTRICT ALL SUBDIRECTORIES WITH USER ISOLATION
    <DirectoryMatch "^$SPOOL_DIR/(?<user>[^/]+)/">
        AuthType Basic
        AuthName "Printer Workspace Isolation"
        AuthUserFile /etc/apache2/.htpasswd
        # Only allow access if the username matches the folder name
        Require expr "%{REMOTE_USER} == reqenv('MATCH_USER')"
        AllowOverride All
    </DirectoryMatch>
EOF

    # Insert the block before the last </VirtualHost>
    sed -i "/<\/VirtualHost>/e cat $TEMP_BLOCK" "$TARGET_FILE"
    rm -f "$TEMP_BLOCK"

    echo "[SUCCESS] Privacy block added for $SPOOL_DIR to $TARGET_FILE."
fi

echo "Restarting Apache to apply changes..."
systemctl restart apache2

echo "--------------------------------------------------------"
echo "Done. All subdirectories of $SPOOL_DIR are now restricted by default."
echo "Public access is still allowed for files in the root of $SPOOL_DIR."
