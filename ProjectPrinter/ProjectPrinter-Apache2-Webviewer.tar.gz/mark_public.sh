#!/bin/bash
# mark_public.sh
# Usage: sudo ./mark_public.sh <directory_name>
# Marks a directory in /printer as "always public" by adding a Require all granted .htaccess file.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

DIR_NAME="$1"

if [ -z "$DIR_NAME" ]; then
    echo "Usage: sudo ./mark_public.sh <directory_name>"
    echo "Example: sudo ./mark_public.sh system_reports"
    exit 1
fi

PRINTER_ROOT="${PRINTER_ROOT:-/printer}"
TARGET_DIR="$PRINTER_ROOT/$DIR_NAME"

echo "Marking directory as public: $TARGET_DIR"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Directory does not exist. Creating it..."
    mkdir -p "$TARGET_DIR"
    chown www-data:www-data "$TARGET_DIR"
    chmod 755 "$TARGET_DIR"
fi

HTACCESS="$TARGET_DIR/.htaccess"

# Generate public .htaccess file
# This overrides the global DirectoryMatch "Deny by Default" rule
cat > "$HTACCESS" <<EOF
# PrinterView: Mark this directory as Always Public
# This file allows everyone to view files in this directory.
Require all granted
EOF

chown www-data:www-data "$HTACCESS"
chmod 644 "$HTACCESS"

echo "----------------------------------------"
echo "[SUCCESS] Directory '$DIR_NAME' is now marked as ALWAYS PUBLIC."
echo "Anyone can view files in this directory without a password."
echo "----------------------------------------"
