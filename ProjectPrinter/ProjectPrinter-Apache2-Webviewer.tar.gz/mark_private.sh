#!/bin/bash
# mark_private.sh
# Usage: sudo ./mark_private.sh <directory_name>
# Makes a "public" directory private again by removing the public override .htaccess.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

DIR_NAME="$1"

if [ -z "$DIR_NAME" ]; then
    echo "Usage: sudo ./mark_private.sh <directory_name>"
    echo "Example: sudo ./mark_private.sh system_reports"
    exit 1
fi

PRINTER_ROOT="${PRINTER_ROOT:-/printer}"
TARGET_DIR="$PRINTER_ROOT/$DIR_NAME"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: Directory '$TARGET_DIR' does not exist."
    exit 1
fi

HTACCESS="$TARGET_DIR/.htaccess"

if [ -f "$HTACCESS" ]; then
    # Check if it was a public override
    if grep -q "Require all granted" "$HTACCESS"; then
        echo "Found public override in $HTACCESS. Removing it..."
        rm "$HTACCESS"
        echo "[SUCCESS] Public override removed. Directory is now PROTECTED by the global security policy."
    else
        echo "Directory already has a customized .htaccess. Removing it for standard security..."
        rm "$HTACCESS"
    fi
else
    echo "Directory already has no local override (currently protected by global policy)."
fi

echo "----------------------------------------"
echo "Would you like to assign a specific password for this directory now?"
read -p "Assign user? (y/n): " choice
if [[ "$choice" =~ ^[Yy]$ ]]; then
    # Use the existing add_user.sh if it exists
    SCRIPT_DIR=$(dirname "$(readlink -f "$0")")
    if [ -f "$SCRIPT_DIR/add_user.sh" ]; then
        bash "$SCRIPT_DIR/add_user.sh" "$DIR_NAME"
    else
        echo "Error: add_user.sh not found."
    fi
fi

echo "----------------------------------------"
echo "Done. Directory '$DIR_NAME' is now restricted."
