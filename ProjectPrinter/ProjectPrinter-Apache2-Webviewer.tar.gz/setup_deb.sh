#!/bin/bash
# setup_deb.sh
# Usage: sudo ./setup_deb.sh [spool_dir]
# Automates the setup of PrinterView on a Debian system.
# spool_dir: Optional. The directory where PDFs are stored (default: /printer)

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

# Configuration: Default spool directory
SPOOL_DIR="${1:-/printer}"
echo "Using spool directory: $SPOOL_DIR"

echo "Updating packages..."
apt-get update

echo "Installing Apache2 and Python3 (if missing)..."
apt-get install -y apache2 python3 apache2-utils

echo "Enabling CGI and Alias modules..."
a2enmod cgi alias rewrite

echo "Ensuring spool directory ($SPOOL_DIR) exists..."
if [ ! -d "$SPOOL_DIR" ]; then
    mkdir -p "$SPOOL_DIR"
    chown www-data:www-data "$SPOOL_DIR"
    chmod 755 "$SPOOL_DIR"
fi

echo "Deploying Application and Management Scripts to /var/www/printer_view..."
WEB_APP_DIR="/var/www/printer_view"
mkdir -p "$WEB_APP_DIR"
cp index.py "$WEB_APP_DIR/"
cp style.css "$WEB_APP_DIR/"
cp *.sh "$WEB_APP_DIR/" 2>/dev/null || true # Copy all scripts if they exist

chmod +x "$WEB_APP_DIR/index.py"
chmod +x "$WEB_APP_DIR"/*.sh
chown -R www-data:www-data "$WEB_APP_DIR"

# Run the security patch script if it's available locally
if [ -f "update_apache_security.sh" ]; then
    echo "Applying 'Privacy by Default' global policy to $SPOOL_DIR..."
    bash update_apache_security.sh "/etc/apache2/sites-available/printer_view.conf" "$SPOOL_DIR"
fi

echo "Configuring Apache Site..."
# We create a specific site config if it doesn't already exist (or we just update it)
cat > /etc/apache2/sites-available/printer_view.conf <<EOF
<VirtualHost *:80>
    # ServerName printer.local
    # Uncomment above if you want this to apply only to a specific domain
    
    DocumentRoot $WEB_APP_DIR

    # 1. Configuration for the Script Interface
    <Directory $WEB_APP_DIR>
        Options +ExecCGI
        AddHandler cgi-script .py
        DirectoryIndex index.py
        AllowOverride All
        Require all granted
        
        # Tell the script where the real files are
        SetEnv PRINTER_ROOT $SPOOL_DIR
    </Directory>

    # 2. Ensure Alias is correctly mapped for downloads
    Alias /printer $SPOOL_DIR
    <Directory $SPOOL_DIR>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
EOF

echo "Enabling Site..."
# Disable default site to avoid conflicts on port 80
a2dissite 000-default.conf || true
a2ensite printer_view.conf
systemctl reload apache2

echo "============================================"
echo "Setup Complete!"
echo "1. The interface is available at http://<your-server-ip>/"
echo "2. Your PDF files are stored in $SPOOL_DIR"
echo "3. Use 'sudo ./add_user.sh <username>' to manage workspaces."
echo "============================================"
