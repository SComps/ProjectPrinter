#!/bin/bash
# fix_printer_view.sh
# Run with: sudo ./fix_printer_view.sh
# This script fixes common issues: line endings, permissions, and module conflicts.

set -e

echo "1. Fixing line endings (Windows -> Linux conversion)..."
sed -i 's/\r$//' /var/www/printer_view/index.py

echo "2. Setting correct permissions..."
chown -R www-data:www-data /var/www/printer_view
chmod 755 /var/www/printer_view/index.py

echo "3. Resetting Apache CGI modules..."
# Disable conflicting modules just in case
a2dismod -f cgi mpm_prefork 2>/dev/null || true
# Enable correct threaded modules
a2enmod mpm_event cgid
# Restart to apply changes and recreate sockets
systemctl restart apache2

echo "4. Testing script execution manually..."
export PRINTER_ROOT=/printer
# Run as www-data to verify user permissions
if su -s /bin/bash www-data -c "/var/www/printer_view/index.py" > /tmp/test_output.html 2>&1; then
    echo "   [SUCCESS] Script ran successfully manually."
    head -n 5 /tmp/test_output.html
else
    echo "   [FAILURE] Script failed to run manually. Error output:"
    cat /tmp/test_output.html
fi

echo "======================================================="
echo "Done. Try refreshing the browser."
echo "If it still fails, run: sudo tail -n 20 /var/log/apache2/error.log"
