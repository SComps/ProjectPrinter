#!/bin/bash
# add_user.sh
# Usage: sudo ./add_user.sh <username>
# Creates a protected user directory under /printer

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

USERNAME="$1"

if [ -z "$USERNAME" ]; then
  echo "Usage: sudo ./add_user.sh <username>"
  exit 1
fi

PRINTER_ROOT="${PRINTER_ROOT:-/printer}"
USER_DIR="$PRINTER_ROOT/$USERNAME"
HTPASSWD_FILE="/etc/apache2/.htpasswd"

echo "Creating user directory: $USER_DIR"
if [ ! -d "$USER_DIR" ]; then
    mkdir -p "$USER_DIR"
    chown www-data:www-data "$USER_DIR"
    chmod 755 "$USER_DIR"
fi

echo "Setting up password protection for user '$USERNAME'..."

# Create or update htpasswd file
if [ ! -f "$HTPASSWD_FILE" ]; then
    echo "Creating new password file..."
    htpasswd -c "$HTPASSWD_FILE" "$USERNAME"
else
    echo "Updating password for existing user..."
    htpasswd "$HTPASSWD_FILE" "$USERNAME"
fi

# Create .htaccess file
HTACCESS="$USER_DIR/.htaccess"
echo "Generating .htaccess..."
cat > "$HTACCESS" <<EOF
AuthType Basic
AuthName "Protected Space for $USERNAME"
AuthUserFile $HTPASSWD_FILE
Require user $USERNAME
EOF

chown www-data:www-data "$HTACCESS"
chmod 644 "$HTACCESS"

echo "Directory protected for user '$USERNAME'."
echo "----------------------------------------"
echo "You can now add PDFs to $USER_DIR"
