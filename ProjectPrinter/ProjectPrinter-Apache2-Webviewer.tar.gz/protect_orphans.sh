#!/bin/bash
# protect_orphans.sh
# Scans /printer for unprotected subdirectories and prompts to protect them.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

PRINTER_ROOT="${PRINTER_ROOT:-/printer}"
SCRIPT_DIR=$(dirname "$(readlink -f "$0")")

if [ ! -d "$PRINTER_ROOT" ]; then
    echo "Error: $PRINTER_ROOT does not exist."
    exit 1
fi

echo "Scanning for unprotected directories in $PRINTER_ROOT..."
echo "--------------------------------------------------------"

FOUND_ORPHAN=false

# Find all subdirectories
for dir_path in "$PRINTER_ROOT"/*/; do
    # Skip if no matches
    [ -e "$dir_path" ] || continue
    
    dir_name=$(basename "$dir_path")
    
    # Check for .htaccess
    if [ ! -f "${dir_path}.htaccess" ]; then
        FOUND_ORPHAN=true
        echo ""
        echo "Found UNPROTECTED directory: $dir_name"
        read -p "Would you like to protect this directory now? (y/n): " choice
        
        case "$choice" in 
          y|Y )
            echo "Starting protection for user '$dir_name'..."
            # Call add_user.sh which will handle directory structure and password prompting
            if [ -f "$SCRIPT_DIR/add_user.sh" ]; then
                bash "$SCRIPT_DIR/add_user.sh" "$dir_name"
            else
                echo "Error: add_user.sh not found in $SCRIPT_DIR"
            fi
            ;;
          * )
            echo "Skipping $dir_name."
            ;;
        esac
    fi
done

if [ "$FOUND_ORPHAN" = false ]; then
    echo "All directories are already protected."
fi

echo "--------------------------------------------------------"
echo "Done."
