#!/bin/bash
# update_live_site.sh
# Usage: sudo ./update_live_site.sh
# Deploys the latest index.py and style.css to the active Apache directory.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (use sudo)"
  exit 1
fi

DEST_DIR="/var/www/printer_view"
SCRIPT_DIR=$(dirname "$(readlink -f "$0")")

if [ ! -d "$DEST_DIR" ]; then
    echo "Creating destination directory: $DEST_DIR"
    mkdir -p "$DEST_DIR"
fi

echo "Deploying updated web pages to $DEST_DIR..."

# Copy core files
cp "$SCRIPT_DIR/index.py" "$DEST_DIR/"
cp "$SCRIPT_DIR/style.css" "$DEST_DIR/"

# Copy management scripts
echo "Deploying management scripts..."
cp "$SCRIPT_DIR/add_user.sh" "$DEST_DIR/"
cp "$SCRIPT_DIR/protect_orphans.sh" "$DEST_DIR/"
cp "$SCRIPT_DIR/update_apache_security.sh" "$DEST_DIR/"
cp "$SCRIPT_DIR/mark_public.sh" "$DEST_DIR/"
cp "$SCRIPT_DIR/mark_private.sh" "$DEST_DIR/"
cp "$SCRIPT_DIR/regenerate_apache_config.sh" "$DEST_DIR/"

# Set permissions
echo "Setting permissions for www-data..."
chown -R www-data:www-data "$DEST_DIR"
chmod 755 "$DEST_DIR/index.py"
chmod 744 "$DEST_DIR"/*.sh
chmod 644 "$DEST_DIR/style.css"

# Optional: Fix line endings in case they were edited in Windows
sed -i 's/\r$//' "$DEST_DIR"/*.py
sed -i 's/\r$//' "$DEST_DIR"/*.css
sed -i 's/\r$//' "$DEST_DIR"/*.sh

echo "Reloading Apache..."
systemctl reload apache2

echo "--------------------------------------------------------"
echo "Done. The live site at $DEST_DIR has been updated."
echo "Visit your server in the browser to see the IBM Z UI."
