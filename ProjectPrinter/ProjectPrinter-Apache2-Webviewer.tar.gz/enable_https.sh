#!/bin/bash
# enable_https.sh
# Usage: sudo ./enable_https.sh
# Enables SSL on Apache and configures the PrinterView to listen on HTTPS (Port 443) using self-signed certs.

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

echo "1. Enabling SSL module..."
a2enmod ssl
a2enmod headers

echo "2. Ensuring 'snakeoil' self-signed certificates exist..."
# This package generates a self-signed cert at installation
apt-get install -y ssl-cert ca-certificates

# If they don't exist for some reason, verify/regenerate
if [ ! -f /etc/ssl/certs/ssl-cert-snakeoil.pem ]; then
    make-ssl-cert generate-default-snakeoil
fi

echo "3. Creating HTTPS configuration..."
WEB_APP_DIR="/var/www/printer_view"

cat > /etc/apache2/sites-available/printer_view_ssl.conf <<EOF
<VirtualHost *:443>
    # ServerName printer.local
    
    DocumentRoot $WEB_APP_DIR
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile      /etc/ssl/certs/ssl-cert-snakeoil.pem
    SSLCertificateKeyFile   /etc/ssl/private/ssl-cert-snakeoil.key
    
    # Enable standard CGI setup
    <Directory $WEB_APP_DIR>
        Options +ExecCGI
        AddHandler cgi-script .py
        DirectoryIndex index.py
        AllowOverride All
        Require all granted
        SetEnv PRINTER_ROOT /printer
    </Directory>

    # Handling the /printer alias
    Alias /printer /printer
    
    # Root of /printer is public for files directly in it
    <Directory /printer>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # PROTECT ALL SUBDIRECTORIES BY DEFAULT
    # Any access attempt to a sub-folder requires a valid user from the .htpasswd
    <DirectoryMatch "^/printer/.+/">
        AuthType Basic
        AuthName "Restricted User Workspace"
        AuthUserFile /etc/apache2/.htpasswd
        Require valid-user
        AllowOverride All
    </DirectoryMatch>

    # Logging
    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF

echo "4. Enabling the HTTPS site..."
a2ensite printer_view_ssl.conf

echo "5. Restarting Apache..."
systemctl restart apache2

echo "======================================================="
echo "HTTPS Enabled!"
echo "Apache is now listening on port 443 using a self-signed certificate."
echo ""
echo "IMPORTANT NGINX NOTE:"
echo "Since this uses a self-signed certificate, your Nginx proxy must be configured to ignore verification errors."
echo "Ensure your Nginx location block includes:"
echo "   proxy_ssl_verify off;"
echo "======================================================="
